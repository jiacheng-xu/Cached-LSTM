path = '../memgroup_2013/yelp2013part_multi_blstm_pro_0.01_adagrad_0.5_24_50_5_True_1e-05_128.npz'
